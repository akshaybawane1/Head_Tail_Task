const About = () => {
  return (
    <>
      <section className="sec Card about-page">
        <h1>About Us</h1>
        <div>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Amet tempore deserunt, pariatur ad possimus quod laudantium, nulla vitae eveniet eligendi reprehenderit ullam dolor repellat architecto consequuntur est aperiam inventore porro aspernatur exercitationem! Cumque, ratione nostrum animi repellendus hic sit dolor, consequatur praesentium fugit sint quo corporis maiores labore qui minima quam illum. Consequatur sequi soluta totam ab eveniet, perferendis at doloribus quia esse nam recusandae ipsum magni animi suscipit tempora consequuntur eos rem alias rerum autem. A repudiandae quam nulla fugiat autem, eligendi, at earum illo cumque, sint tempore delectus porro quod nobis consequuntur iure laboriosam id reprehenderit accusantium eius?</div>
      </section>
    </>
  )
}

export default About
