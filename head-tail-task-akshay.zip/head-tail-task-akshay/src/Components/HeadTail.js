import { useEffect, useRef, useState } from "react"
const HeadTail = () => {
  const selVal = useRef()
  const [prev, setPrev] = useState()
  const [arr, setArr] = useState([])
  // const arr = [["H"]]
  // const arr = [["H","H","H"],["T","T"]]

  useEffect(() => console.log(arr), [arr])

  const showErr = () => {
    return function () {
      document.getElementById("err").style.display = "block"
      setTimeout(() => {
        document.getElementById("err").style.display = "none"
      }, 2000)
    }
  }
  const func = showErr()

  const handleSubmit = e => {
    e.preventDefault()
    // console.log(selVal.current.value)
    console.log(arr.length)
    const newVal = selVal.current.value
    if (newVal !== "NS") {
      if (arr.length === 0) {
        setArr([[newVal]])
        setPrev(newVal)
        selVal.current.value = "NS"
      } else {
        if (newVal === prev) {
          // console.log(newVal)
          const newArr = arr
          newArr[newArr.length - 1].push(newVal)
          setArr([...newArr])
          setPrev(newVal)
          selVal.current.value = "NS"
          // console.log(arr)
        } else {
          const newArr = arr
          newArr.push([newVal])
          setArr([...newArr])
          setPrev(newVal)
          selVal.current.value = "NS"
        }
      }
    } else {
      // alert("Please Select value")
      func()
    }
  }

  return (
    <>
      <section className="Card head-tail">
        <form className="input-sec" onSubmit={handleSubmit}>
          <div>
            <select id="sel-val" ref={selVal}>
              <option value="NS" disabled selected>
                Select
              </option>
              <option value="H">Head</option>
              <option value="T">Tail</option>
            </select>
            <span id="err">Please select Head/Tail</span>
          </div>
          <button className="btn-sm">Submit</button>
        </form>

        <div className="main-content">
          {arr.map(item => {
            return (
              <div>
                {item.map(item2 => {
                  return <p>{item2}</p>
                })}
              </div>
            )
          })}
          {/* <div>
            <p>H</p>
            <p>H</p>
            <p>H</p>
            <p>H</p>
            <p>H</p>
            <p>H</p>
          </div>
          <div>
            <p>T</p>
            <p>T</p>
            <p>T</p>
            <p>T</p>
          </div>
          <div>
            <p>H</p>
            <p>H</p>
            <p>H</p>
          </div> */}
        </div>
      </section>
    </>
  )
}

export default HeadTail
