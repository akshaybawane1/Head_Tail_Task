import { Link } from "react-router-dom"

const Home = () => {
  return (
    <>
      <section className="sec Card">
        <Link to="/about">
          <div className="btn">About</div>
        </Link>
        <Link to="/head-tail-page">
          <div className="btn">Head & Tail</div>
        </Link>
      </section>
    </>
  )
}

export default Home
