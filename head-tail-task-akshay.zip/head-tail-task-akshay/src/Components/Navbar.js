import { Link } from "react-router-dom"

const Navbar = () => {
  return (
    <div className="navbar Card">
      <Link to="/Head_Tail_Task">Home</Link>
    </div>
  )
}

export default Navbar
