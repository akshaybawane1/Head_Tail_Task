import "./App.css"
import { BrowserRouter, Routes, Route } from "react-router-dom"
import Navbar from "./Components/Navbar"
import Home from "./Components/Home"
import About from "./Components/About"
import HeadTail from "./Components/HeadTail"

function App() {
  return (
    <>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/Head_Tail_Task" exact element={ <Home />} />
          <Route path="/about" exact element={ <About />} />
          <Route path="/head-tail-page" exact element={ <HeadTail />} />
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
